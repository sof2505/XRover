import React from "react";

import rovertImage from '../imagenes/nuestroRovert.jpg';
import Rovertxd1 from "../imagenes/Rovertxd.jpg";
import Rovertxd2 from "../imagenes/Rovertxd2.jpg";
import Rovertxd3 from "../imagenes/Rovertxd3.jpg";

import Header from "../componentes/Header"

function Home(){
    return(
        <div className="home-container">
            <header>
                <Header/>
            </header>
            <hr className="hr"/>
            <div className="contenedor-texto">
                <p className="texto">Controle y visualice los datos de su exploración en tiempo real.</p>
            </div>
            <div className='contenido-principal'>
                    <div className='cuadro-blanco'>
                        <div className='imagenes'>
                            <div className='carrusel-dinamico'>
                                <div className="slides">
                                    <div className="slide">
                                        <img src={Rovertxd1} alt="XRover Image 1" className="imagenG"/>
                                    </div>
                                    <div className="slide">
                                        <img src={Rovertxd2} alt="XRover Image 2" className="imagenG"/>
                                    </div>
                                    <div className="slide">
                                        <img src={Rovertxd3} alt="XRover Image 3" className="imagenG"/>
                                    </div>
                                    <div className="navegacion">
                                        <span className="prev">&#10094;</span>
                                        <span className="next">&#10095;</span>
                                    </div>
                                </div>
                            </div>
                            <div className='imagen-estatica'>
                                <img src={rovertImage} alt="Nuestro Rover" className="imagenP" />
                            </div>
                        </div>
                        <a className='manejarnow'>Manejar ahora</a>
                    </div>
                </div>
        </div>
    );
}
export default Home;