import React from "react";
import mqtt from "mqtt";  // Asegúrate de tener esta librería instalada

const client = mqtt.connect("wss://broker.hivemq.com:8884/mqtt");  // Conexión al broker MQTT

function manejar() {
  // Función para enviar los comandos de movimiento
  const enviarMovimiento = (direccion) => {
    client.publish("bts/rover/movimiento", direccion);
    console.log(`Movimiento enviado: ${direccion}`,(err) => {
        if (err) {
          console.error("Error al suscribirse:", err);
        } else {
          console.log("Suscripción exitosa al tópico 'bts/sensor1'");
        }
      });
  };

  return (
    <div className="controles">
      <button className="Avanzar" onClick={() => enviarMovimiento("adelante")}>Avanza</button>
      <button className="Derecha" onClick={() => enviarMovimiento("derecha")}>Derecha</button>
      <button className="Atras" onClick={() => enviarMovimiento("atras")}>Atrás</button>
      <button className="Izquierda" onClick={() => enviarMovimiento("izquierda")}>Izquierda</button>
      <button className="parar" onClick={() => enviarMovimiento("parar")}>parar</button>
    </div>
  );
}

export default manejar;
