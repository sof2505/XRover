import Mando from "../imagenes/cruceta.webp";
import Header from "../componentes/Header";
import Control from "./manejar";

import Acelerometro from "../Graficassql/Datosacelerometro"
import Fotomysql from "../Graficassql/Fotosql";
import Temmysql from "../Graficassql/Humedadsql";
import Ultrasql from "../Graficassql/Ultrasql";

function DatosDeSensores() {

  return (
    <div>
      <header>
        <Header />
      </header>
      <hr className="hr"/>
      <div className="contenedor-joystick-texto">
        <img src={Mando} alt="Mando" className="Mando" />
        <p className="texto-joystick">Presiona los botones y maneja el rover a donde tú quieras.</p>
      </div>

      <Control/>

      <hr className="hr"/>
      <Fotomysql/>
      <hr className="hr"/>
      <Acelerometro/>
      <hr className="hr"/>
      <Ultrasql/>
      <hr className="hr"/>
      <Temmysql/>
      <hr className="hr"/>


    </div>
  );
}

export default DatosDeSensores;
