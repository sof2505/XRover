import React from 'react';
import minirovert from "../imagenes/Minirover.webp";
import { Link } from 'react-router-dom';
//este archivo Header.js esta en la carpeta src/componentes

function Header() {
  return (
      <div className="contenido">
        <header>
          <div className="header-left">
            <img id="Imagen-XRover" src={minirovert} alt="Xrover" />
            <h2>XRover IDE</h2>
          </div>
          <nav className='header-right'>
            <ul>
              <li> <Link className="Home" to= "/"> Home</Link></li>
              <li><Link className="Datos_de_sensore" to="/DatosSensores">Datos De Sensores</Link></li>
              <li><a className="Configuracion" >Graficas</a></li>
              <li><a className="Soporte">Ayuda</a></li>
            </ul>
          </nav>
        </header>
        </div>
    );
}

export default Header;
