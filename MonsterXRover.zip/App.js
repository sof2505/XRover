
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from "./componentes/Home";
import DatosDeSensores from "./componentes/DatosSensores";

import './App.css';


function App() {
  return (
    <Router>
      <div className="contenido">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/DatosSensores" element={<DatosDeSensores />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

