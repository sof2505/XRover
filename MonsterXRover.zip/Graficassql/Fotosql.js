import ReactApexChart from "react-apexcharts";
import React, { useState, useEffect } from "react";
import mqtt from "mqtt";
import axios from "axios";

const GraficaFotoresistencia = () => {
  const [fotoresistenciaData, setFotoresistenciaData] = useState({
    values: [],
    dates: [],
  });

  useEffect(() => {
    const obtenerDatos = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8000/fotoresistencia");
        const data = response.data;
        setFotoresistenciaData({
          values: data.map((entry) => entry.lectura_luz), // Usamos "lectura_luz" de la API
          dates: data.map((entry) => entry.fecha),       // Usamos "fecha" de la API
        });
      } catch (error) {
        console.error("Error al obtener datos de fotoresistencia:", error);
      }
    };
  
    obtenerDatos();
  }, []); // Ejecutar una vez al montar el componente  

  const chartOptions = {
    chart: {
      type: "area",
      height: 350,
      zoom: { enabled: false },
      background: "#ffffff",
    },
    title: {
      text: "Gráfica de Intensidad de Luz (Fotoresistencia)",
      align: "left",
      style: { fontSize: "20px", fontWeight: "bold", color: "#333" },
    },
    subtitle: {
      text: "Intensidad de luz a lo largo del tiempo (lux o valor relativo)",
      align: "left",
      style: { fontSize: "14px", color: "#666" },
    },
    dataLabels: { enabled: false },
    stroke: { curve: "smooth" },
    labels: fotoresistenciaData.dates,
    xaxis: {
      type: "datetime",
      title: { text: "Tiempo", style: { fontSize: "14px", fontWeight: "bold", color: "#333" } },
    },
    yaxis: {
      title: { text: "Intensidad de Luz (lux)", style: { fontSize: "14px", fontWeight: "bold", color: "#333" } },
      opposite: true,
    },
    legend: { horizontalAlign: "left" },
  };

  return (
    <div className="grafica-container">
      <div className="grafica-foto">
        <ReactApexChart
          options={chartOptions}
          series={[{ name: "Intensidad de Luz", data: fotoresistenciaData.values }]}
          type="area"
          height={350}
        />
      </div>
    </div>
  );
};

export default GraficaFotoresistencia;
