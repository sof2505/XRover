import ReactApexChart from "react-apexcharts";
import React, { useState, useEffect } from "react";
import axios from "axios";

const GraficaUltrasonico = () => {
  const [ultrasonicData, setUltrasonicData] = useState({
    values: [],
    dates: [],
  });

  useEffect(() => {
    const obtenerDatos = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8000/distancia_ultrasonico");
        const data = response.data;
  
        setUltrasonicData({
          values: data.map((entry) => entry.distancia),
          dates: data.map((entry) => entry.fecha), 
        });
      } catch (error) {
        console.error("Error al obtener datos del sensor de temperatura:", error);
      }
    };
  
    obtenerDatos();
  }, []);

  const chartOptions = {
    chart: {
      type: "area",
      height: 350,
      zoom: { enabled: false },
      background: "#ffffff",
    },
    title: {
      text: "Gráfica de Distancia Ultrasonico",
      align: "left",
      style: { fontSize: "20px", fontWeight: "bold", color: "#333" },
    },
    subtitle: {
      text: "Distancia en centímetros (cm) a lo largo del tiempo",
      align: "left",
      style: { fontSize: "14px", color: "#666" },
    },
    dataLabels: { enabled: false },
    stroke: { curve: "smooth" },
    labels: ultrasonicData.dates,
    xaxis: {
      type: "datetime",
      title: { text: "Tiempo", style: { fontSize: "14px", fontWeight: "bold", color: "#333" } },
    },
    yaxis: {
      title: { text: "Distancia (cm)", style: { fontSize: "14px", fontWeight: "bold", color: "#333" } },
      opposite: true,
    },
    legend: { horizontalAlign: "left" },
  };

  return (
    <div className="grafica-container">
    <div className="grafica-sensores">
      <ReactApexChart
        options={chartOptions}
        series={[{ name: "Distancia", data: ultrasonicData.values }]}
        type="area"
        height={350}
      />
    </div>
    </div>
  );
};

export default GraficaUltrasonico;
