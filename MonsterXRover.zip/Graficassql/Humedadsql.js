import ReactApexChart from "react-apexcharts";
import React, { useState, useEffect } from "react";
import axios from "axios";

function DatosDeHumedad() {
  const [sensorData, setSensorData] = useState({
    temperatura: [],
    presion: [],
    altitud: [],
    dates: [],
  });

    // Conectar al broker MQTT
    useEffect(() => {
        const obtenerDatos = async () => {
          try {
            const response = await axios.get("http://127.0.0.1:8000/temperatura_sensor");
            const data = response.data;
      
            setSensorData({
              temperatura: data.map((entry) => entry.temperatura),
              presion: data.map((entry) => entry.humedad),
              altitud: data.map((entry) => entry.altitud),
              dates: data.map((entry) => entry.fecha),
            });
          } catch (error) {
            console.error("Error al obtener datos del sensor de temperatura:", error);
          }
        };
      
        obtenerDatos();
      }, []);
      
      
  const chartOptions = {
    chart: {
      type: "line",
      height: 350,
      background: "#ffffff",
    },
    title: {
      text: "Gráfica de Temperatura, Presión y Altitud",
      align: "left",
      style: { fontSize: "20px", fontWeight: "bold", color: "#333" },
    },
    xaxis: {
      type: "datetime",
      title: {
        text: "Tiempo",
        style: { fontSize: "14px", fontWeight: "bold", color: "#333" },
      },
      categories: sensorData.dates, // Usar las fechas como eje X
    },
    yaxis: [
      {
        title: {
          text: "Temperatura (°C)",
          style: { fontSize: "14px", fontWeight: "bold", color: "#f63a11" },
        },
        labels: {
          style: { colors: "#f63a11" },
        },
      },
      {
        opposite: true,
        title: {
          text: "Presión (hPa)",
          style: { fontSize: "14px", fontWeight: "bold", color: "#0cafe0" },
        },
        labels: {
          style: { colors: "#0cafe0" },
        },
      },
      {
        opposite: false,
        title: {
          text: "Altitud (m)",
          style: { fontSize: "14px", fontWeight: "bold", color: "#06de1e" },
        },
        labels: {
          style: { colors: "#06de1e" },
        },
      },
    ],
    colors: ["#f63a11", "#0cafe0", "#06de1e"],
    legend: {
      position: "top",
      horizontalAlign: "left",
    },
    tooltip: {
      shared: true,
      intersect: false,
    },
  };

  return (
    <div className="grafica-container">
      <div className="grafica-humedad">
        <ReactApexChart
          options={chartOptions}
          series={[
            { name: "Temperatura (°C)", data: sensorData.temperatura },
            { name: "Presión (hPa)", data: sensorData.presion },
            { name: "Altitud (m)", data: sensorData.altitud },
          ]}
          type="line"
          height={350}
        />
      </div>
    </div>
  );
}

export default DatosDeHumedad;
