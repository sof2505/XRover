import ReactApexChart from "react-apexcharts";
import React, { useState, useEffect } from "react";
import axios from "axios";

const DatosDeacelerometro = () => {
  const [accelerationData, setAccelerationData] = useState({
    values: [],
    dates: [],
  });

  useEffect(() => {
    // Función para obtener datos desde la API
    const obtenerDatos = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8000/acelerometro"); // URL de tu API FastAPI
        const data = response.data;

        if (Array.isArray(data) && data.length > 0 && 'lectura_x' in data[0] && 'fecha' in data[0]) {
          setAccelerationData({
            values: data.map((entry) =>
              Math.sqrt(entry.lectura_x ** 2 + entry.lectura_y ** 2 + entry.lectura_z ** 2)
            ),
            dates: data.map((entry) => entry.fecha),
          });
        } else {
          console.error("Datos en formato inesperado:", data);
        }
      } catch (error) {
        console.error("Error al obtener los datos del acelerómetro:", error);
      }
    };

    // Configurar el intervalo para realizar polling
    const intervalo = setInterval(obtenerDatos, 1000); // Llamada cada 1 segundo

    // Limpiar el intervalo cuando el componente se desmonte
    return () => clearInterval(intervalo);
  }, []); // Este efecto se ejecuta al montar el componente

  const chartOptions = {
    chart: {
      type: "area",
      height: 350,
      zoom: { enabled: false },
      background: "#ffffff",
    },
    title: {
      text: "Gráfica de Aceleración del XRover",
      align: "left",
      style: { fontSize: "20px", fontWeight: "bold", color: "#333" },
    },
    subtitle: {
      text: "Datos de aceleración en m/s² a lo largo del tiempo",
      align: "left",
      style: { fontSize: "14px", color: "#666" },
    },
    dataLabels: { enabled: false },
    stroke: { curve: "smooth" },
    labels: accelerationData.dates,
    xaxis: {
      type: "datetime",
      title: { text: "Tiempo", style: { fontSize: "14px", fontWeight: "bold", color: "#333" } },
    },
    yaxis: {
      title: { text: "Modulo de Aceleración (m/s²)", style: { fontSize: "14px", fontWeight: "bold", color: "#333" } },
      opposite: true,
    },
    legend: { horizontalAlign: "left" },
  };

  return (
    <div className="grafica-container">
      <div className="grafica-sensores">
        <ReactApexChart
          options={chartOptions}
          series={[{ name: "Aceleración", data: accelerationData.values }]}
          type="area"
          height={350}
        />
      </div>
    </div>
  );
};

export default DatosDeacelerometro;
